package seccim.project.wiv.portalaluno;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.opengl.Visibility;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TarefasActivity extends AppCompatActivity {

    HomeActivity homeActivity;

    ListView listViewDesafios;

    Desafio desafioSelecionado;
    Desafio listaDeDesafios[];

    SwipeRefreshLayout swipper;

    SurfaceView surface_Camera;
    CameraSource cameraSource;
    TextView text_QRDescription;
    CardView buttonFecharScanner;

    BarcodeDetector barcodeDetector;
    FrameLayout frameLayout;

    QrReader qrReader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listViewDesafios = findViewById(R.id.listViewDesafios);
        listViewDesafios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selecionarDesafio(position);
            }
        });

        swipper = findViewById(R.id.swipeToUpdate);
        swipper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh()
            {
                requerirDesafios();
                swipper.setRefreshing(false);
                Toast.makeText(getApplicationContext(), "Lista atualizada!", Toast.LENGTH_LONG).show();
            }
        });

        qrReader = new QrReader();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment, qrReader).commit();

        frameLayout = findViewById(R.id.frameLayout);

        surface_Camera = findViewById(R.id.surfaceView);

        text_QRDescription = findViewById(R.id.txt_ScanResult);

        buttonFecharScanner = findViewById(R.id.buttonFecharScanner);
        buttonFecharScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fecharScannerQR();
            }
        });

        barcodeDetector = new BarcodeDetector.Builder(this).setBarcodeFormats(Barcode.QR_CODE).build();

        cameraSource = new CameraSource.Builder(this, barcodeDetector).setRequestedPreviewSize(512, 512).build();

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> qrCode = detections.getDetectedItems();

                User user = User.getSingletonObject();

                if (qrCode.size() > 0)
                {
                    if (qrCode.valueAt(0).displayValue.equals(desafioSelecionado.getQr()))
                    {
                       finish();
                       user.setPontuacao(user.getPontuacao() + desafioSelecionado.getPontuacao());
                       Toast.makeText(getApplicationContext(), qrCode.valueAt(0).displayValue, Toast.LENGTH_LONG);
                    }

                    text_QRDescription.post(new Runnable() {
                        @Override
                        public void run() {
                            text_QRDescription.setText("Código Inválido!");
                        }
                    });
                }}
        });

        requerirDesafios();

    }

    public void selecionarDesafio(int posicao)
    {
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
       {
           return;
       }

        try {
            cameraSource.start(surface_Camera.getHolder());
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.desafioSelecionado = listaDeDesafios[posicao];
        frameLayout.setVisibility(View.VISIBLE);
    }

    public void fecharScannerQR()
    {
        cameraSource.stop();
        frameLayout.setVisibility(View.GONE);
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == android.R.id.home)
        {
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void btnAtualizarListaDesafios(View view)
    {
        requerirDesafios();
    }

    public void requerirDesafios()
    {

        MainActivity0.trustAllCertificates();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                "https://192.168.100.5/sqlconnect/ListarDesafios.php",
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        //progressBar.setVisibility(ProgressBar.GONE);
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if (!jsonObject.getBoolean("error"))
                            {
                                atualizarListaDeDesafios(jsonObject);
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void atualizarListaDeDesafios(JSONObject jsonObject) throws JSONException
    {
        if (jsonObject == null)
            return;

        JSONArray array = jsonObject.getJSONArray("desafios");
        listaDeDesafios = new Desafio[array.length()];

        for (int i = 0; i < array.length(); i++) {

            JSONObject des = array.getJSONObject(i);

            String descricao = des.getString("descricao");
            String qr = des.getString("qr");
            int pontuacao = des.getInt("pontuacao");
            int id = des.getInt("id");
            String horario_inicio = des.getString("tempo_inicio");

            listaDeDesafios[i] = new Desafio(id, qr, descricao, pontuacao, horario_inicio);

        }

        String titulos[] = new String[array.length()];
        for (int i = 0; i < array.length(); i++)
        {
            titulos[i] = listaDeDesafios[i].getDescricao();
        }

        MyAdapter adaptador = new MyAdapter(getBaseContext(), listaDeDesafios, titulos);
        listViewDesafios.setAdapter(adaptador);

        return;
    }

    class MyAdapter extends ArrayAdapter<String>
    {
        Context context;
        Desafio desafios[];

        MyAdapter(Context c, Desafio desafios[], String titulos[])
        {
            super(c, R.layout.desafio, R.id.textView_Descricao, titulos);
            this.context = c;
            this.desafios = desafios;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.desafio, parent, false);

            TextView descricao = row.findViewById(R.id.textView_Descricao);
            TextView tempoRestante = row.findViewById(R.id.textView_TempoRestante);

            descricao.setText(desafios[position].getDescricao());
            tempoRestante.setText("Expira em: " + desafios[position].getHorario_inicio());

            return row;
        }
    }
}
