package seccim.project.wiv.portalaluno;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CadastroActivity extends AppCompatActivity {

    private EditText editTextNomeCadastro, editTextEmailCadastro, editTextSenhaCadastro, editTextConfirmPassword;
    private ProgressBar progressBar;
    private CardView buttonCadastro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        progressBar = findViewById(R.id.progressBarCadastro);

        editTextNomeCadastro = findViewById(R.id.editTextNome);
        editTextNomeCadastro.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editTextNomeCadastro.setTextColor(Color.BLACK);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }});

        editTextEmailCadastro = findViewById(R.id.editTextEmail);
        editTextEmailCadastro.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editTextEmailCadastro.setTextColor(Color.BLACK);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }});

        editTextSenhaCadastro = findViewById(R.id.editTextSenha);
        editTextSenhaCadastro.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editTextSenhaCadastro.setTextColor(Color.BLACK);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }});

        editTextConfirmPassword = findViewById(R.id.editTextSenha2);
        editTextConfirmPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editTextConfirmPassword.setTextColor(Color.BLACK);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }});

        buttonCadastro = findViewById(R.id.cardViewCadastro);
        buttonCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String nome = editTextNomeCadastro.getText().toString().trim();
                final String senha = editTextSenhaCadastro.getText().toString().trim();
                final String confirmPassword = editTextConfirmPassword.getText().toString().trim();
                final String email = editTextEmailCadastro.getText().toString().trim();

                boolean error = false;

                if (nome.length() <= 4)
                {
                    editTextNomeCadastro.setTextColor(Color.RED);
                    error = true;
                }

                if (senha.length() <= 4)
                {
                    editTextSenhaCadastro.setTextColor(Color.RED);
                    error = true;
                }

                if (!senha.equals(confirmPassword))
                {
                    editTextConfirmPassword.setTextColor(Color.RED);
                    editTextSenhaCadastro.setTextColor(Color.RED);
                    error = true;
                }

                if (!email.matches(".+@.+\\.[a-z]+"))
                {
                    editTextEmailCadastro.setTextColor(Color.RED);
                    error = true;
                }

                if (!error)
                    btnCadastrarUsuario();
            }
        });
    }

    public void btnCadastrarUsuario()
    {
        final String nome = editTextNomeCadastro.getText().toString().trim();
        final String senha = editTextSenhaCadastro.getText().toString().trim();
        final String email = editTextEmailCadastro.getText().toString().trim();

        progressBar.setVisibility(ProgressBar.VISIBLE);

        MainActivity0.trustAllCertificates();
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                "https://192.168.100.5/sqlconnect/Registrar.php",
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        progressBar.setVisibility(ProgressBar.GONE);
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();

                            if (!jsonObject.getBoolean("error"))
                            {
                                finish();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        progressBar.setVisibility(ProgressBar.GONE);
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                params.put("nome", nome);
                params.put("senha", senha);
                params.put("email", email);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home)
        {
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void btnCancelar(View view)
    {
        this.finish();
    }
}
