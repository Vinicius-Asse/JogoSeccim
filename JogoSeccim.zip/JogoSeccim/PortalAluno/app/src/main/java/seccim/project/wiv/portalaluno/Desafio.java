package seccim.project.wiv.portalaluno;

import java.util.Date;

public class Desafio {

    private int id;
    private String descricao;
    private String qr;
    private int pontuacao;
    private String horario_inicio;

    public Desafio(int id, String qr, String descricao, int pontuacao, String horario_inicio)
    {
        this.id = id;
        this.qr = qr;
        this.descricao = descricao;
        this.pontuacao = pontuacao;
        this.horario_inicio = horario_inicio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getQr() {
        return qr;
    }

    public void setQr(String qr) {
        this.qr = qr;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

    public String getHorario_inicio() {
        return horario_inicio;
    }

    public void setHorario_inicio(String horario_inicio) {
        this.horario_inicio = horario_inicio;
    }
}
