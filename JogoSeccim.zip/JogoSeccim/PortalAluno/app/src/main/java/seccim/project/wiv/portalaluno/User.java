package seccim.project.wiv.portalaluno;

import android.app.Activity;

public class User {

    public static User singletonObject;

    private HomeActivity homeActivity;
    private String nome;
    private String email;
    private String macAdress;
    private int pontuacao;

    public static synchronized User getSingletonObject()
    {
        if (singletonObject == null)
        {
            singletonObject = new User();
        }
        return singletonObject;
    }

    public HomeActivity getHomeActivity() {
        return homeActivity;
    }

    public void setHomeActivity(HomeActivity homeActivity) {
        this.homeActivity = homeActivity;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMacAdress() {
        return macAdress;
    }

    public void setMacAdress(String macAdress) {
        this.macAdress = macAdress;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        if (this.homeActivity == null)
            return;

        this.pontuacao = pontuacao;
        this.homeActivity.atualizarPontuacao(pontuacao);
    }
}
