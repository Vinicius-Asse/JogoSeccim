<?php

	define('DB_NAME', 'databaseJogo');
	define('DB_USERNAME', 'localuser');
	define('DB_PASSWORD', 'localuser');
	define('DB_HOST', 'localhost');

?>