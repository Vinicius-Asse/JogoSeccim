<?php

	class DbConnect
	{
		private $con;

		function __construct()
		{

		}

		function connect()
		{
			//Importa o Header de Constantes
			include_once dirname(__FILE__) . '/Constantes.php';

			//Cria uma coneccao com o banco de dados
			$this->con = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);


			//Checa se ocorreu algum erro
			if(mysqli_connect_errno()){
                exit();
            }
            
			//Retorna a coneccao caso tudo tenha dado certo
			return $this->con;

		}
	}
?>