<?php

	class Jogador
	{
		public $nome;
		public $email;
		public $pontuacao;

		function __construct($nome, $email, $pontuacao)
		{
			$this->nome = $nome;
			$this->email = $email;
			$this->pontuacao = $pontuacao;
		}
	}

	class DbOperations
	{
		private $con;

		function __construct()
		{
			//Solicita os dados da coneccao

			require_once dirname(__FILE__) . '/DbConnect.php';

			//Cria uma coneccao
			$db = new DbConnect();

			//Define $con como sendo a coneccao
			$this->con = $db->connect();
		}

		function createUser($nome_de_usuario, $email, $senha)
		{
			//Encriptografando a senha
			$senha_criptografada = md5($senha);

			//Verificando se ja existe um usuario cadastrado com mesmo nome
			//**//
			//Verifica essa desgraça dps pq agora to sem paciencia

			//Inserindo o novo usuario ao Banco de Dados
			$stmt = $this->con->prepare("INSERT INTO jogadores (nome, email, senha) VALUES (?, ?, ?);");
			$stmt->bind_param("sss", $nome_de_usuario, $email, $senha_criptografada);

			if ($stmt->execute())
			{
				return true;
			}
			else
			{
				$response = array("error", "message");

				$response["error"] = true;
				$response["message"] = $stmt->error;
				exit();
			}
		}

		function userLogIn($email, $senha)
		{
			//Encriptografando a senha
			$senha_criptografada = md5($senha);

			$stmt = $this->con->prepare("SELECT nome, email, pontuacao FROM jogadores WHERE email = ? AND senha = ?;");
			$stmt->bind_param("ss", $email, $senha_criptografada);
			$stmt->execute();
			$stmt->store_result();

			//Caso só uma entidade seja encontrada
			if ($stmt->num_rows == 1)
			{

				//Bind do resultado nas seguintes variáveis
				$result = $stmt->bind_result($nome, $email, $pontuacao);

				//Pega os resultados
				$stmt->fetch();

				//Instancia um novo valor com suas propriedades
				$jogador = new Jogador($nome, $email, $pontuacao);

				//Encerra a conexao
				$stmt->close();

				//Retorna o jogador
				return $jogador;
			}
			
			//Senão deu ruim
			else
			{
				return null;
			}
		}

		function getDesafios()
		{

			$desafios = array();

			$result = $this->con->query("SELECT * FROM desafios;");

			$i = 0;
			while ($row = mysqli_fetch_assoc($result))
			{
				$desafios[$i]['id'] = $row['id'];
				$desafios[$i]['qr'] = $row['qr'];
				$desafios[$i]['descricao'] = $row['descricao'];
				$desafios[$i]['pontuacao'] = $row['pontuacao'];
				$desafios[$i]['tempo_inicio'] = $row['tempo_inicio'];
				$desafios[$i]['validade'] = $row['validade'];

				$i = $i + 1;
			}

			return $desafios;
		}
	}
?>