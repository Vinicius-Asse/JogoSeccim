<?php

	require_once'../include/DbOperations.php';

	$response = array();

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		if (isset($_POST['email']) and isset($_POST['senha']))
		{

			$db = new DbOperations();
			$jogador = new Jogador();

			if ($jogador = $db->userLogin($_POST['email'], $_POST['senha']))
			{
				$response['error'] = false;
				$response['message'] = "Seja bem vindo, " . $jogador->nome . "! :)";

				$response['nome'] = $jogador->nome;
				$response['pontuacao'] = $jogador->pontuacao;
			}
			else
			{
				$response['error'] = true;
				$response['message'] = "Erro de autenticação";
			}
		}
		else 
		{
			$response['error'] = true;
			$response['message'] = "Preencha todos os campos Email: " . $POST["email"];
		}
	}
	else
	{
		$response['error'] = true;
		$response['message'] = "Pedido Inválido";
	}

	echo json_encode($response);

?>