<?php

	require_once'../include/DbOperations.php';

	$response = array();

	if ($_SERVER['REQUEST_METHOD'] == 'GET')
	{
		$db = new DbOperations();

		if ($desafios = $db->getDesafios())
		{

			$response['error'] = false;
			$response['message'] = "Lista atualizada!! :)";

			$response['desafios'] = $desafios;
		}
		else
		{
			$response['error'] = true;
			$response['message'] = "Erro de autenticação";
		}
	}

	else
	{
		$response['error'] = true;
		$response['message'] = "Pedido Inválido";
	}

	echo json_encode($response);
?>