<?php

	require_once'../include/DbOperations.php';

	$response = array();

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		if (isset($_POST['nome']) and isset($_POST['senha']) and isset($_POST['email']))
		{

			$db = new DbOperations();

			if ($db->createUser(
					$_POST['nome'],
					$_POST['email'],
					$_POST['senha']))
			{
				$response['error'] = false;
				$response['message'] = "Usuario cadastrado com sucesso";
			}
			else
			{
				$response['error'] = true;
				$response['message'] = "Algo errado aconteceu";
			}
		}
		else 
		{
			$response['error'] = true;
			$response['message'] = "Preencha todos os campos";
		}
	}
	else
	{
		$response['error'] = true;
		$response['message'] = "Pedido Inválido";
	}

	echo json_encode($response);

?>